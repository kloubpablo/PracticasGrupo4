﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplicationAPP.Models
{
    internal class Laboratorio
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public int Capacity { get; set; }

        public string Responsible { get; set; }


    }
    
}
